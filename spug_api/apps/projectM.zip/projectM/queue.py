from django.views.generic import View
from apps.projectM.models import project1,queue
from apps.projectM.readsupervisor import fetch_queue,flushque
from libs import json_response, auth, JsonParser, Argument

class queueView(View):
    def get(self, request):
        form, error = JsonParser(
            Argument('project_id', type=int,help='项目ID为空！'),
        ).parse(request.body)
        if error is None:
            rec1 = queue.objects.get(project_id=form.project_id)
            response=[]
            for item in rec1:
                iteminfo=item.to_view()
                response.append(iteminfo)
            return json_response({"quedata":response})

def queflush(request):
    form, error = JsonParser(
        Argument('project_id', type=int, help='项目ID为空！'),
    ).parse(request.body)
    if error is None:
        flushque(form.project_id)
        rec1 = queue.objects.get(project_id=form.project_id)
        response = []
        for item in rec1:
            iteminfo = item.to_view()
            response.append(iteminfo)
        return json_response({"quedata": response})

