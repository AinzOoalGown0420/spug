from django.urls import path
from apps.projectM.views import *
from apps.projectM.queue import *

urlpatterns = [
    path('', projectView.as_view()),
    path('info/', updateInfo),
    path('queue/', queueView.as_view()),
    path('queue/flush', queflush),
]